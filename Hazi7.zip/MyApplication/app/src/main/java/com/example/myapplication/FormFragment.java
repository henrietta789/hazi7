package com.example.myapplication;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;


public class FormFragment extends Fragment {

    Button send_button, list_button, image_button, bday_button;
    EditText name_editText, ex_editText;
    Spinner location_spinner, department_spinner;
    CheckBox y_checkBox, n_checkBox;
    RadioButton I_radio, II_radio, III_radio, IV_radio;
    DatePickerDialog dpd;
    RadioGroup gendergroup, departmentgroup;
    TextView nTv;
    Calendar c;
    private static final int PICK_IMAGE_REQUEST = 1;
    DatabaseReference frb;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v= inflater.inflate(R.layout.fragment_form, container, false);
        send_button = v.findViewById(R.id.send_button);
        list_button = v.findViewById(R.id.list_button);
        image_button = v.findViewById(R.id.image_button);
        bday_button = v.findViewById(R.id.date_button);
        name_editText = v.findViewById(R.id.name_editText);
        ex_editText = v.findViewById(R.id.ex_editText);
        location_spinner = v.findViewById(R.id.location_spinner);
        department_spinner = v.findViewById(R.id.department_spinner);
        y_checkBox = v.findViewById(R.id.yap_checkBox);
        n_checkBox = v.findViewById(R.id.nope_checkBox);
        I_radio = v.findViewById(R.id.I_radioButton);
        II_radio = v.findViewById(R.id.II_radioButton);
        III_radio = v.findViewById(R.id.III_radioButton);
        IV_radio = v.findViewById(R.id.IV_radioButton);
        nTv = v.findViewById(R.id.date_textView);



        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getActivity(),R.array.location, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        location_spinner.setAdapter(adapter);
        ArrayAdapter<CharSequence> dep_adapter = ArrayAdapter.createFromResource(getActivity(),R.array.department, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        department_spinner.setAdapter(dep_adapter);
        send_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(getActivity(), "Data inserted", Toast.LENGTH_LONG).show();
            }
        });

        list_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction fr=getFragmentManager().beginTransaction();
                fr.replace(R.id.fragment_container,new ListFragment());
                fr.commit();

            }
        });
        bday_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                c= Calendar.getInstance();
                int day = c.get(Calendar.DAY_OF_MONTH);
                int month = c.get(Calendar.MONTH);
                int year = c.get(Calendar.YEAR);
                dpd = new DatePickerDialog(getActivity(), new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int nYear, int nMonth, int nDay) {
                        nTv.setText(nDay + "/" + (nMonth+1)+"/"+ nYear);
                    }
                },day,month,year);
                dpd.show();

            }

        });
        image_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseImage();
            }
        });

        return v;
    }
    private void chooseImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }
}

